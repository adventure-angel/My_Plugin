"""Local client for the installed Codex Blender Bridge addon."""
import argparse
import json
import os
import socket
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

def config_dir():
    return Path(os.environ["APPDATA"]) / "Blender Foundation" / "Blender" / "5.2" / "config"

def request(command, params, port=9878, timeout=30):
    token = (config_dir() / "codex_blender_bridge.token").read_text(encoding="ascii").strip()
    payload = json.dumps({"type": command, "params": params, "token": token}, ensure_ascii=False).encode("utf-8")
    with socket.create_connection(("127.0.0.1", port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall(payload)
        chunks = []
        while True:
            part = sock.recv(65536)
            if not part:
                break
            chunks.append(part)
            try:
                return json.loads(b"".join(chunks).decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
    raise RuntimeError("Blender closed the connection without a complete response")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command")
    parser.add_argument("--params", default="{}")
    parser.add_argument("--code-file")
    parser.add_argument("--port", type=int, default=9878)
    parser.add_argument("--timeout", type=float, default=30)
    args = parser.parse_args()
    if args.command == "sent-selection":
        path = config_dir() / "codex_blender_bridge_selection.json"
        print(path.read_text(encoding="utf-8") if path.exists() else "{}")
        return
    params = json.loads(args.params)
    if args.code_file:
        params["code"] = Path(args.code_file).read_text(encoding="utf-8")
    result = request(args.command, params, args.port, args.timeout)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result.get("status") != "success":
        sys.exit(1)

if __name__ == "__main__":
    main()
