"""Call the local Blender modeling backend without a DSH account."""
import argparse
import json
import sys
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("route", help="plan, view, act, frame, worker, job, etc.")
    parser.add_argument("--body", default="{}", help="JSON request body")
    parser.add_argument("--body-file", help="Read JSON request body from a UTF-8 file")
    parser.add_argument("--get", action="store_true")
    parser.add_argument("--output", help="Write a binary/image response to this path")
    parser.add_argument("--port", type=int, default=9887)
    parser.add_argument("--timeout", type=float, default=300)
    args = parser.parse_args()
    route = args.route.strip("/")
    if not route:
        parser.error("route is required")
    raw_body = args.body
    if args.body_file:
        from pathlib import Path
        raw_body = Path(args.body_file).read_text(encoding="utf-8")
    body = None if args.get else json.dumps(json.loads(raw_body), ensure_ascii=False).encode("utf-8")
    request = Request("http://127.0.0.1:%d/%s" % (args.port, route), data=body,
                      headers={"Content-Type": "application/json"})
    try:
        with urlopen(request, timeout=args.timeout) as response:
            content = response.read()
    except HTTPError as exc:
        content = exc.read()
        sys.stderr.write("HTTP %d\n" % exc.code)
        sys.stderr.buffer.write(content)
        sys.exit(1)
    except URLError as exc:
        parser.error("Blender backend unavailable: %s" % exc.reason)
    if args.output:
        from pathlib import Path
        Path(args.output).write_bytes(content)
        print(args.output)
        return
    try:
        decoded = json.loads(content.decode("utf-8"))
    except json.JSONDecodeError:
        lines = content.decode("utf-8", errors="replace").splitlines()
        try:
            decoded = next(json.loads(line) for line in reversed(lines)
                           if line.strip() and not json.loads(line).get("heartbeat"))
        except (StopIteration, json.JSONDecodeError, AttributeError):
            sys.stdout.buffer.write(content)
            return
    print(json.dumps(decoded, ensure_ascii=False, indent=2))
    if isinstance(decoded, dict) and decoded.get("ok") is False:
        sys.exit(1)


if __name__ == "__main__":
    main()
