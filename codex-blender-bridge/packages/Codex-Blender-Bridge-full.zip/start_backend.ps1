$ErrorActionPreference = 'Stop'
$backend = Join-Path $PSScriptRoot 'backend'
$env:DSH_BLENDER_ADDON_PORT = '9878'
$env:DSH_BLENDER_HTTP_PORT = '9887'
$env:CBB_TOKEN_FILE = Join-Path $env:APPDATA 'Blender Foundation/Blender/5.2/config/codex_blender_bridge.token'
if (-not (Test-Path -LiteralPath $env:CBB_TOKEN_FILE)) {
    throw '先在 Blender 里启用 Codex Blender Bridge 插件并连接。'
}
$logDir = Join-Path $env:LOCALAPPDATA 'CodexBlenderBridge/logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$existing = Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort 9887 -State Listen -ErrorAction SilentlyContinue
if ($existing) {
    Write-Output '建模后端已经在 127.0.0.1:9887 运行。'
    return
}
$process = Start-Process -FilePath 'node.exe' -ArgumentList 'lib/runtime/server.js' -WorkingDirectory $backend -RedirectStandardOutput (Join-Path $logDir 'backend-out.log') -RedirectStandardError (Join-Path $logDir 'backend-err.log') -WindowStyle Hidden -PassThru
Write-Output ("建模后端已启动，PID {0}，端口 9887。" -f $process.Id)
