# Codex Blender Bridge

本机 Blender 5.2 插件。Blender 侧基于 sixtysevenlf/dsh-blender-plugin v3.0.3 的 MIT 插件代码改造；原作者 Siddharth Ahuja 的署名与许可见插件内 LICENSE-MIT.txt、NOTICE.md。

## 已安装位置

%APPDATA%\Blender Foundation\Blender\5.2\scripts\addons\codex_blender_bridge

本机 Blender 5.2.3 LTS 的首选项已经启用插件。打开 3D 视图，按 N，切换到 **Codex Blender Bridge** 标签。插件默认自动连接本机 127.0.0.1:9878，也可在面板中断开或重连。

## 面板功能

- 活动状态（人、AI、同时、空闲）与暂停/继续 AI 写操作。
- 当前选中对象、活动对象、编辑模式子元素；多选与整集合模式。
- 可折叠、可滚动且可调高度的对象和集合成员列表。
- “保存选中给 Codex”按钮把按下时的选区快照写到本机 Blender 配置目录。当前 Codex Desktop 没有供外部 Blender 插件直接插入此聊天草稿的接口，因此快照需由 Codex 本机客户端读取。
- Poly Haven、Sketchfab、Poly Pizza、Hyper3D Rodin、腾讯混元 3D 的配置面板与原有接入命令。需要各服务自己的可用账号/API 设置；本次未向这些服务提交请求，也未验证付费或生成能力。
- 38 条继承的 Blender 侧命令，包括场景与对象检查、视口截图、Python 执行、选区和集合读取、场景导出，以及上述服务的门控命令。
- 新增 `modeling_modules`、`modeling_catalog`、`modeling_op` 三条建模运行库命令。打包原仓库 v3.0.3 的 Python 建模模块，在 Blender 主线程中按需加载；提供造型、曲面、雕刻、UV、材质、参考图量测、白模、装配检查、网格审计、渲染和交付等操作。无需 DeepSeek 账号，当前 Codex 对话可经本机客户端调用。

## 建模运行库怎么用

先列模块，再查一个模块的操作，最后用该模块自己的 `help` 了解参数：

    python client.py modeling_modules
    python client.py modeling_catalog --params '{"module":"geo"}'
    python client.py modeling_op --params '{"module":"geo","op":"help","args":{}}'

例如创建盒体（坐标按 Blender 单位；具体参数以 `help` 为准）：

    python client.py modeling_op --params '{"module":"geo","op":"box","args":{"name":"Demo","xr":[-0.05,0.05],"yr":[-0.02,0.02],"zr":[0,0.025]}}'

插件里的 35 个公开模块在 Blender 5.2.3 中逐一加载、列出 311 个可调用入口；其中也包含 help 和内部辅助入口，不等同于原仓库宿主层的“228 个 plan op”。

## 建模后端：原仓库宿主能力

完整包还带有改适配的原仓库 v3.0.3 Node 建模后端。它连接我们的插件端口 9878 并读取本机令牌，在 127.0.0.1:9887 提供 29 条路由，不需要 DeepSeek 账号或 OpenAI API Key。它提供原仓库的 34 类别 / 228 个 plan op，以及实时截图、连续执行、无头 worker、长任务、事务、配方、性能分析等能力。Codex 在本机通过 `backend_client.py` 调用这些路由；它们不是 Codex 应用里单独显示的 15 个原生按钮。

在完整包解压目录中运行 `powershell -File start_backend.ps1` 启动后端；Node.js 需为 24.9 或更新。当前机器已安装 Node 24.18。启动后可用：

    python backend_client.py doctor --get
    python backend_client.py plan --body '{"op":"catalog","args":{}}'
    python backend_client.py plan --body '{"op":"audit_scene","args":{"summary_only":true}}'
    python backend_client.py frame.png?size=420 --get --output viewport.png

需要在当前 GUI 场景连续执行代码时，先领取写租约，再执行，最后释放：

    python backend_client.py lease --body '{"holder":"codex-modeling","ttlMs":30000}'
    python backend_client.py act --body '{"holder":"codex-modeling","code":"import bpy; print(len(bpy.context.scene.objects))"}'
    python backend_client.py release --body '{"holder":"codex-modeling"}'

常用对应关系：原仓库 `blender_rt_plan` → `plan`，`blender_rt_see` → `frame.png` / `view`，`blender_rt_do` → `act`，`blender_rt_worker` → `worker`，`blender_rt_headless` → `headless`，`blender_rt_job` → `job`，`blender_rt_txn` → `txn`，`blender_rt_preset` → `preset`，`blender_rt_perf` → `perf`，`blender_rt_opt` → `opt`，`blender_rt_loop` → `loop`，`blender_rt_cmd` → `cmd`，`blender_rt_commands` → `commands`，`blender_viewport` → `doctor` / `status` / `lease` 等路由。各路由参数从 `plan` 的 `catalog`（`args={"tool":"rt_worker"}` 等）查询。

对当前 GUI 场景的写操作要遵守后端写租约；可先调用 `lease`，结束后调用 `release`。无头 worker 可传 `isolated:true` 使用独立进程。`frame.png` 是图像接口，旧的 `/frame` 网页入口已被上游移除。

`modeling_op` 和后端写路由可修改当前场景，应先保存工程。调用返回值中的 `ok`、`verdict` 和警告需要逐项核对；列出操作不代表每个算法的成品效果已验证。少数上游模块依赖可选环境，实际调用时会报告错误，不会静默代替成功。

## 本机客户端

client.py 与插件包一起提供。它从 Blender 配置目录读取本机令牌，经 127.0.0.1:9878 发送命令；不要在命令行参数里粘贴令牌。

示例：

    python client.py ping
    python client.py get_scene_info
    python client.py get_selection
    python client.py sent-selection
    python client.py get_viewport_screenshot --params "{\"max_size\":800,\"filepath\":\"C:/path/viewport.png\",\"format\":\"png\"}"
    python client.py execute_code --code-file my_blender_script.py

连接只监听本机，所有命令需要令牌。暂停时，写入命令被拒绝，只读查询仍可使用。execute_code 可以执行任意 Blender Python，因此只让可信的本机进程使用该客户端与令牌文件。

## 本次核验

在 Blender 5.2.3 LTS GUI 会话中实测：面板显示、连接/断开状态、活动状态、对象选区按钮、集合按钮、编辑模式子元素快照（8 顶点、12 边、6 面）、暂停/恢复、环境与模型服务开关展开、读取场景、离屏视口截图、创建并清理测试物体。另从 GUI 会话导出 Cube 为 GLB，并用独立 Blender 后台进程重新导入，读回 Cube 网格。建模运行库逐一加载 35 个公开模块，`geo.box` 实际创建并读回 8 顶点网格后清理。改适配后端的 `doctor` 返回 `kind=ok`，`plan catalog` 报 34 类 / 228 op，`audit_scene` 在 GUI 中成功执行；`frame.png` 生成 420px 视口 PNG，`lease → act → release` 在 GUI 读回 3 个场景对象，`worker start/stop` 在独立 Blender 5.2.3 进程中完成。场景目前保持默认 Cube、Light、Camera。

第三方素材和模型服务仅验证了面板与开关，没有发起外部 API 请求；账号、费用和生成效果均未实测。
