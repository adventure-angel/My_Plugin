export declare const RECOVER_VERSION = "2.6.1";
export interface MapPair {
    winToWsl: (p: string) => string;
    wslToWin: (p: string) => string;
}
export interface LogEvidence {
    path: string | null;
    exists: boolean;
    bytes: number;
    mtime: number | null;
    lastStage: string | null;
    sawDone: boolean;
    sawScriptEnd: boolean;
    sawHeadless: boolean;
    sawTraceback: boolean;
    lastProgress: Record<string, unknown> | null;
    tail: string | null;
    error?: string;
}
/**
 * 读日志尾部并抽"终态证据"。只读尾部，避免大日志把进程拖死。
 * 返回 { exists, bytes, mtime, lastStage, sawDone, sawScriptEnd, sawHeadless, sawTraceback,
 *        lastProgress, path, tail, error? }
 */
export declare function logEvidence(pathWsl: string, maxBytes?: number): LogEvidence;
export interface RecoverOut {
    found: boolean;
    source: string | null;
    status: string | null;
    exitCode: unknown;
    finishedAt: number | null;
    artifacts: unknown[];
    evidence: Record<string, unknown> | null;
    stdoutLog: string | null;
    stderrLog: string | null;
    lastProgress: Record<string, unknown> | null;
}
/**
 * 在磁盘上找"这条 run/job 已经跑完"的证据。
 * rec 可含：dir / jobDir / outdir / resultPath / stdoutLog / stdoutLogWsl / logs
 * map = {winToWsl, wslToWin}
 */
export declare function recoverFromDisk(rec: Record<string, unknown> | null | undefined, map?: MapPair): RecoverOut;
/**
 * 把一条 status=running 的磁盘台账记录收敛成终态。
 *  - pid 还活着 → 原样返回（不抢）
 *  - pid 没了但磁盘有终态证据 → status=done/failed + recovered:true
 *  - 否则 → status=stale（保留旧语义），但附 evidence 让调用方少一次破案
 */
export declare function reconcileLedger(rec: Record<string, unknown> | null, map?: MapPair, isAlive?: (pid: unknown) => boolean): Record<string, unknown> | null;
