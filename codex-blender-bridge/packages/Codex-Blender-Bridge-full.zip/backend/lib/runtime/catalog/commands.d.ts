export declare const COMMAND_CATALOG: Record<string, {
    d: string;
    gate: string | null;
}>;
