/**
 * v0.9.3（D2）：run（blender_rt_headless 的同步执行）与 job 同一份结构化回执形状 ——
 * collect/status 收 run-… 与 job-… 都是同一套字段，调用方不必分辨两者。
 */
declare function runSnapshot(r: Record<string, unknown>): Record<string, unknown>;
/**
 * 磁盘台账记录（后端重启后的历史）：running 但 pid 已不存在时的收敛。
 *
 * v2.6（本轮反馈 #1）：旧版一律判 stale —— 但实测两次「子进程其实已经跑完、产物/日志都在」，
 * 调用方要自己 Get-Process + ls 破案，每次至少赔一轮往返。现在先做磁盘对账：
 *   summary.json / resultPath / stdout 终态（DSH_STAGE done、HEADLESS、Traceback）
 * 对得上 ⇒ status=done|failed + recovered=true（证据在 recoveredFrom/recoveredEvidence）；
 * 对不上才判 stale，并把 evidence（日志大小/lastStage）附回去。
 * 纯逻辑在 runtime/recover.ts，可脱离 Blender 单测（tests/unit/js/ledger-recover.test.ts）。
 */
declare function reconcileLedger(rec: Record<string, unknown> | null): Record<string, unknown> | null;
export declare function createLedgerRecover(): {
    runSnapshot: typeof runSnapshot;
    reconcileLedger: typeof reconcileLedger;
};
export {};
