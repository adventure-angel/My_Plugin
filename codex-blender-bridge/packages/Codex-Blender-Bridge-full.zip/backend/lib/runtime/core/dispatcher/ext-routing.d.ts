import type { PlanCallDeps } from './index.js';
import type { RouteDecision } from './plan-call.js';
export declare function routeExtRouting(E: PlanCallDeps, o: string, payload: unknown): Promise<RouteDecision>;
