import type { EngineApiDeps } from './index.js';
export declare function createFrameApi(E: EngineApiDeps): {
    frameArea(areaIndex?: number): Promise<{
        png: NonSharedBuffer;
        meta: {
            method: string;
            info: string;
        };
    }>;
    /** 渲染性能：status / apply / revert / analyze / help */
    perf(op: string, payload?: unknown): Promise<unknown>;
    /** 对象精简：opt_analyze / opt_join */
    opt(op: string, payload?: unknown): Promise<unknown>;
    /** 取一帧视口 PNG（覆盖写固定文件） */
    frame(maxSize?: number): Promise<{
        png: NonSharedBuffer;
        meta: unknown;
    }>;
};
