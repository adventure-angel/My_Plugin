import type { EngineApiDeps } from './index.js';
export declare function createHostApi(E: EngineApiDeps): {
    hostSceneItems(spec?: Record<string, unknown>): Promise<Record<string, unknown>>;
    /**
     * 启动时连上常驻 socket，并**尽力**补一次 `get_addon_info`（不 await、失败即忽略 ——
     * 绝不让"addon 没起来"或"addon 正忙"拖慢后端启动）。
     */
    start(): Promise<boolean>;
    stop(): void;
};
