import type { EngineApiDeps } from './index.js';
export declare function statusView(E: EngineApiDeps): Promise<Record<string, unknown>>;
export declare function createDoctorApi(E: EngineApiDeps): {
    protocol(): Promise<import("../../transport/probes.js").ProtocolInfoView>;
    /** 现场体检：真跑一次 bpy 往返（status），通了才算 ok；不通才去三级判定 */
    doctor(): Promise<{
        ok: boolean;
        addon: import("../../transport/probes.js").Diagnosis;
        metrics: Record<string, unknown>;
        error?: undefined;
    } | {
        ok: boolean;
        addon: {
            kind: string;
            tcp: boolean;
            ping: boolean;
            ping_ms: number | null;
            roundTripMs: number;
            summary: string;
            protocol: string | null;
            protocol_label: string | undefined;
            protocol_from: string | undefined;
            fix: string;
            region: unknown;
        };
        metrics: Record<string, unknown>;
        error?: undefined;
    } | {
        ok: boolean;
        addon: import("../../transport/probes.js").Diagnosis;
        metrics: Record<string, unknown>;
        error: string;
    }>;
    /** 3D 视口区域 rect / 窗口尺寸 / 着色模式 */
    status(): Promise<Record<string, unknown>>;
    commands(): Promise<{
        scene: unknown;
        file: unknown;
        total: number;
        available: string[];
        disabled: string[];
        gates: Record<string, unknown>;
        integrations: Record<string, unknown>;
    }>;
};
