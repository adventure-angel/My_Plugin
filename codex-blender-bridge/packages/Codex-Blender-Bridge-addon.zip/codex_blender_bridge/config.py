""" Configuration, environment variables, preferences and auto-start. """

import bpy
import socket
import requests
import os
from bpy.app.handlers import persistent

from .compat import ADDON_MODULE

# 兼容回退（旧环境变量名）：先读新名，取不到再读改名前的旧名。
# 旧名只出现在下面这张表里，用户已经设置的环境变量不会失效。
_LEGACY_ENV_VARS = {
    # These are environment variable names, not credentials.
    "CBB_HYPER3D_API_KEY": "BLENDERMCP_HYPER3D_API_KEY",  # gitleaks:allow
    "CBB_SKETCHFAB_API_KEY": "BLENDERMCP_SKETCHFAB_API_KEY",  # gitleaks:allow
    "CBB_POLYPIZZA_API_KEY": "BLENDERMCP_POLYPIZZA_API_KEY",  # gitleaks:allow
    "CBB_HUNYUAN3D_SECRET_ID": "BLENDERMCP_HUNYUAN3D_SECRET_ID",  # gitleaks:allow
    "CBB_HUNYUAN3D_SECRET_KEY": "BLENDERMCP_HUNYUAN3D_SECRET_KEY",  # gitleaks:allow
    "CBB_HUNYUAN3D_API_URL": "BLENDERMCP_HUNYUAN3D_API_URL",  # gitleaks:allow
}


def read_env_var(name):
    """读环境变量：新名优先，兼容回退到旧名（改名前的版本）。"""
    value = os.getenv(name)
    if value:
        return value
    legacy = _LEGACY_ENV_VARS.get(name)
    return os.getenv(legacy) if legacy else None


RODIN_FREE_TRIAL_KEY = "vibecoding"
DISCORD_URL = "https://discord.gg/SNqPn4TcKQ"
# Public site link shown by the N-panel; kept here so UI code does not import
# the integration clients.
POLYHAVEN_SITE = "https://polyhaven.com"

# Add User-Agent as required by Poly Haven API
REQ_HEADERS = requests.utils.default_headers()
REQ_HEADERS.update({"User-Agent": "dsh-blender-bridge"})

# Set when the user disconnects so opening another blend file does not restart
# the server behind their back. A manual connect or add-on reload clears it.
_user_stopped_server = False


def _cbb_port_has_listener(host, port):
    """Return True when another process already owns the MCP endpoint."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.settimeout(0.15)
    try:
        return probe.connect_ex((host, port)) == 0
    finally:
        probe.close()


def _cbb_ensure_server_running():
    """Start the bridge after Blender's UI and scene context are ready.

    Returning a delay asks Blender's timer system to retry when a launch-time
    socket or context race prevented the first attempt.
    """
    if bpy.app.background:
        return None

    scene = getattr(bpy.context, "scene", None)
    if scene is None:
        return 0.5

    server = getattr(bpy.types, "cbb_server", None)
    if not scene.cbb_auto_start_server or _user_stopped_server:
        scene.cbb_server_running = bool(server is not None and server.running)
        return None

    port = scene.cbb_port
    if server is None:
        from .server import CodexBlenderBridgeServer

        if _cbb_port_has_listener("localhost", port):
            scene.cbb_server_running = False
            print(f"Codex Blender Bridge: port {port} is already in use; auto-start skipped.")
            return None
        server = CodexBlenderBridgeServer(port=port)
        bpy.types.cbb_server = server  # pyright: ignore[reportAttributeAccessIssue]

    if not server.running:
        # Safe while stopped and necessary when a newly loaded scene selects a
        # different port. Never retarget an active connection.
        server.port = port
        server.start()

    scene.cbb_server_running = server.running

    return None if server.running else 1.0


def _cbb_schedule_auto_start(delay=0.5):
    """Schedule one persistent startup callback if none is already pending."""
    if not bpy.app.timers.is_registered(_cbb_ensure_server_running):
        bpy.app.timers.register(
            _cbb_ensure_server_running,
            first_interval=delay,
            persistent=True,
        )


@persistent
def _cbb_load_post(_unused):
    """Retry auto-start after Blender loads a startup file or another blend."""
    _cbb_schedule_auto_start()


def register_auto_start():
    """Install the load handler and defer the initial startup attempt."""
    global _user_stopped_server
    _user_stopped_server = False
    if _cbb_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_cbb_load_post)
    _cbb_schedule_auto_start()


def unregister_auto_start():
    """Remove callbacks owned by the add-on before it is disabled."""
    if _cbb_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_cbb_load_post)
    if bpy.app.timers.is_registered(_cbb_ensure_server_running):
        bpy.app.timers.unregister(_cbb_ensure_server_running)


def get_cbb_addon_preferences(context=None):
    """Get add-on preferences object if available."""
    if context is None:
        context = bpy.context
    addon = context.preferences.addons.get(ADDON_MODULE)  # pyright: ignore[reportAttributeAccessIssue]
    return addon.preferences if addon else None


DEFAULT_DSH_BACKEND = "http://127.0.0.1:9877"


def cbb_backend_url():
    try:
        url = bpy.context.scene.cbb_backend_url  # pyright: ignore[reportAttributeAccessIssue]
    except Exception:
        url = ""
    return (url or DEFAULT_DSH_BACKEND).rstrip("/")
