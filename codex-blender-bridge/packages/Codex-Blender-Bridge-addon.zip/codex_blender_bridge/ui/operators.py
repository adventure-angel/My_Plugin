""" Operators. """

import bpy

from ..commands.selection import best_collection_for_selection, record_selection_send, send_collection_to_codex, send_selection_to_codex
from .. import config
from ..config import RODIN_FREE_TRIAL_KEY, get_cbb_addon_preferences
from ..protocol import redraw_view3d_panels
from ..server import CodexBlenderBridgeServer

class CBB_OT_ToggleAIPause(bpy.types.Operator):
    """暂停 / 继续 AI 操作（拒绝 Codex 发来的 Blender 写操作）"""
    bl_idname = "cbb.toggle_ai_pause"
    bl_label = "暂停 AI 操作"
    bl_description = "暂停后模型只能做只读查询；在 N 面板顶部点「继续 AI 操作」恢复"

    def execute(self, context):
        scene = context.scene
        scene.cbb_ai_paused = not bool(getattr(scene, "cbb_ai_paused", False))
        redraw_view3d_panels()
        if scene.cbb_ai_paused:
            self.report({'WARNING'}, "AI 操作已暂停（只读查询仍可用）")
        else:
            self.report({'INFO'}, "AI 操作已恢复")
        return {'FINISHED'}


# Operator to set Hyper3D API Key
class CBB_OT_SetFreeTrialHyper3DAPIKey(bpy.types.Operator):
    bl_idname = "cbb.set_hyper3d_free_trial_api_key"
    bl_label = "Set Free Trial API Key"

    def execute(self, context):
        prefs = get_cbb_addon_preferences(context)
        if prefs:
            if not prefs.hyper3d_api_key or prefs.hyper3d_api_key == RODIN_FREE_TRIAL_KEY:
                prefs.hyper3d_api_key = RODIN_FREE_TRIAL_KEY
            else:
                self.report(
                    {'INFO'},
                    "Using free trial for this session only; saved private key was kept."
                )
        context.scene.cbb_hyper3d_api_key = RODIN_FREE_TRIAL_KEY
        context.scene.cbb_hyper3d_mode = 'MAIN_SITE'
        self.report({'INFO'}, "API Key set successfully!")
        return {'FINISHED'}

# Operator to start the server
class CBB_OT_SendSelectionToCodex(bpy.types.Operator):
    """发送当前原生选中到 Codex（保存选区快照供当前 Codex 对话读取）"""
    bl_idname = "cbb.send_selection_to_codex"
    bl_label = "保存选中给 Codex"
    bl_description = "把当前选中的物体保存为本机快照；在 Codex 对话中可读取"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        try:
            return bool(context.selected_objects)
        except Exception:
            return False

    def execute(self, context):
        result = record_selection_send(send_selection_to_codex())
        if result.get("ok"):
            self.report({'INFO'}, "已保存选中给 Codex（seq %s）" % result.get("seq"))
        else:
            self.report({'WARNING'}, "保存失败：%s"
                        % (result.get("error") or result.get("hint") or "unknown"))
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class CBB_OT_UseSelectionCollection(bpy.types.Operator):
    """把「集合」下拉设为当前选中对象最常出现的集合"""
    bl_idname = "cbb.use_selection_collection"
    bl_label = "用选中对象的集合"
    bl_description = "当前选中对象分布在多个集合时，自动挑最相关的一个填进「集合」下拉"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            return best_collection_for_selection() is not None
        except Exception:
            return False

    def execute(self, context):
        best = best_collection_for_selection()
        if best is None:
            self.report({'WARNING'}, "当前选中对象不属于任何集合")
            return {'CANCELLED'}
        try:
            context.scene.cbb_collection_target = best
        except Exception as exc:
            self.report({'WARNING'}, "设置集合失败：%s" % str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, "已选集合「%s」（%d 件）" % (best.name, len(best.objects)))
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class CBB_OT_ListRowsInc(bpy.types.Operator):
    """把 N 面板列表加高一点"""
    bl_idname = "cbb.list_rows_inc"
    bl_label = "列表加高"
    bl_description = "把对象 / 成员列表的高度增加 2 行（3–30）"

    @classmethod
    def poll(cls, context):
        try:
            return int(getattr(context.scene, "cbb_list_rows", 8)) < 30
        except Exception:
            return False

    def execute(self, context):
        scene = context.scene
        scene.cbb_list_rows = min(30, int(getattr(scene, "cbb_list_rows", 8)) + 2)
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class CBB_OT_ListRowsDec(bpy.types.Operator):
    """把 N 面板列表变矮一点"""
    bl_idname = "cbb.list_rows_dec"
    bl_label = "列表变矮"
    bl_description = "把对象 / 成员列表的高度减少 2 行（3–30）"

    @classmethod
    def poll(cls, context):
        try:
            return int(getattr(context.scene, "cbb_list_rows", 8)) > 3
        except Exception:
            return False

    def execute(self, context):
        scene = context.scene
        scene.cbb_list_rows = max(3, int(getattr(scene, "cbb_list_rows", 8)) - 2)
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class CBB_OT_SendCollectionToCodex(bpy.types.Operator):
    """把一个集合整体发送到 Codex（大装配体推荐）"""
    bl_idname = "cbb.send_collection_to_codex"
    bl_label = "保存集合给 Codex"
    bl_description = "把 N 面板「集合」下拉里选中的集合保存为本机快照"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        try:
            return getattr(context.scene, "cbb_collection_target", None) is not None
        except Exception:
            return False

    def execute(self, context):
        target = getattr(context.scene, "cbb_collection_target", None)
        name = getattr(target, "name", None) if target else None
        result = record_selection_send(send_collection_to_codex(collection_name=name))
        if result.get("ok"):
            self.report({'INFO'}, "已保存集合「%s」到 Codex（seq %s）" % (name, result.get("seq")))
        else:
            self.report({'WARNING'}, "保存集合失败：%s"
                        % (result.get("error") or result.get("hint") or "unknown"))
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class CBB_OT_StartServer(bpy.types.Operator):
    bl_idname = "cbb.start_server"
    bl_label = "Connect to Codex"
    bl_description = "Start the Codex Blender Bridge server to connect with Codex"

    def execute(self, context):
        config._user_stopped_server = False
        scene = context.scene

        # Create a new server instance
        if not hasattr(bpy.types, "cbb_server") or not bpy.types.cbb_server:
            bpy.types.cbb_server = CodexBlenderBridgeServer(port=scene.cbb_port)

        # Start the server
        bpy.types.cbb_server.start()
        scene.cbb_server_running = bpy.types.cbb_server.running

        return {'FINISHED'}

# Operator to stop the server
class CBB_OT_StopServer(bpy.types.Operator):
    bl_idname = "cbb.stop_server"
    bl_label = "Stop the connection to Codex"
    bl_description = "Stop the connection to Codex"

    def execute(self, context):
        config._user_stopped_server = True
        scene = context.scene

        # Stop the server if it exists
        if hasattr(bpy.types, "cbb_server") and bpy.types.cbb_server:
            bpy.types.cbb_server.stop()
            del bpy.types.cbb_server

        scene.cbb_server_running = False

        return {'FINISHED'}

# Operator to open Terms and Conditions
class CBB_OT_OpenTerms(bpy.types.Operator):
    bl_idname = "cbb.open_terms"
    bl_label = "View Terms and Conditions"
    bl_description = "Open the Terms and Conditions document"

    def execute(self, context):
        # Open the Terms and Conditions on GitHub
        terms_url = "https://github.com/ahujasid/blender-mcp/blob/main/TERMS_AND_CONDITIONS.md"
        try:
            import webbrowser
            webbrowser.open(terms_url)
            self.report({'INFO'}, "Terms and Conditions opened in browser")
        except Exception as e:
            self.report({'ERROR'}, f"Could not open Terms and Conditions: {str(e)}")

        return {'FINISHED'}
