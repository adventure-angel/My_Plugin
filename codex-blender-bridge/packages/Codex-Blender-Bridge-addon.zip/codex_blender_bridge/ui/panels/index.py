""" Main N-panel: activity state, connection, selection and community links. """

import textwrap

import bpy

from ...commands import selection as selection_commands
from ...commands.selection import selection_collection_summary
from ...config import DISCORD_URL, cbb_backend_url
from ...protocol import ai_paused
from ...recorders.activity import get_activity_tracker
from ...ui.lists import LIST_UI_CAP, log_panel_error, sub_mode_label


class CBB_PT_Panel(bpy.types.Panel):
    bl_label = "Codex Blender Bridge"
    bl_idname = "CBB_PT_Panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Codex Blender Bridge"

    def draw(self, context):
        # 包一层：任何绘制异常都记录下来（用户不方便开控制台），并尽量不把整个面板拖黑
        try:
            self._draw_impl(context)
        except Exception as exc:
            import traceback
            tb = traceback.format_exc()
            log_panel_error(tb)
            try:
                context.scene.cbb_last_panel_error = tb[-3000:]
            except Exception:
                pass
            try:
                self.layout.label(text="面板绘制异常：" + str(exc)[:120], icon="ERROR")
            except Exception:
                pass

    def _draw_impl(self, context):
        layout = self.layout
        scene = context.scene
        activity = self._activity_snapshot()
        self._draw_activity(layout, activity)
        self._draw_connection(layout, scene)
        tools_box = layout.box()
        tools_box.label(text="建模运行库已接入", icon="MODIFIER")
        tools_box.label(text="造型 · 材质 · 参考图 · 装配 · 验收")
        tools_box.label(text="在 Codex 对话中调用建模命令")
        self._draw_selection(layout, scene, activity)
        # Upstream community promotion omitted in local adaptation.

    @staticmethod
    def _activity_snapshot():
        try:
            return get_activity_tracker().snapshot(include_current_command=False)
        except Exception:
            return {}

    @staticmethod
    def _draw_activity(layout, activity):
        # v2.5 · 活动状态置顶（AI 操作时警告）+ 暂停 AI 操作
        layout.separator()
        act_box = layout.box()
        state = str(activity.get("state") or "idle")
        state_text = {"human": "人：操作中", "agent": "AI：执行中",
                      "both": "人 / AI 同时活动", "idle": "空闲"}.get(state, state)
        paused = ai_paused()
        if state in ("agent", "both"):
            warn = act_box.row()
            warn.alert = True
            warn.label(text="AI 正在操作 Blender" + ("（同时有人操作）" if state == "both" else ""),
                       icon="ERROR")
        else:
            act_box.label(text="活动状态：" + state_text)
        if paused:
            prow = act_box.row()
            prow.alert = True
            prow.label(text="AI 操作已暂停 · 模型请求会被拒绝")
        btn_row = act_box.row()
        btn_row.scale_y = 1.2
        btn_row.operator("cbb.toggle_ai_pause",
                         text=("继续 AI 操作" if paused else "暂停 AI 操作"))
        if activity.get("last_human_kind"):
            act_box.label(text="最近人类动作：" + str(activity.get("last_human_kind")))

    @staticmethod
    def _draw_connection(layout, scene):
        # Connection
        box = layout.box()
        col = box.column()
        if scene.cbb_server_running:
            server = getattr(bpy.types, "cbb_server", None)
            running_port = getattr(server, "port", scene.cbb_port)
            col.label(text=f"Connected on port {running_port}", icon="CHECKMARK")
            col.operator("cbb.stop_server", text="Disconnect", icon="X")
        else:
            col.label(text="Not connected", icon="RADIOBUT_OFF")
            col.prop(scene, "cbb_port")
            col.operator("cbb.start_server", text="连接 Codex", icon="PLAY")

    def _draw_selection(self, layout, scene, activity):
        # v1.8 · Selection → Codex（在 Blender 原生选区里选，按按钮保存选区快照供 Codex 读取）
        layout.separator()
        layout.label(text="Selection → Codex")
        sel_box = layout.box()
        selection = activity.get("selection") or {}
        sel_count = int(selection.get("count") or 0)
        sel_names = list(selection.get("names") or [])
        mode = str(getattr(scene, "cbb_selection_mode", "MULTI") or "MULTI")
        mode_row = sel_box.row(align=True)
        mode_row.prop(scene, "cbb_selection_mode", expand=True)
        sel_col = sel_box.column(align=True)
        if mode == "COLLECTION":
            self._draw_collection_selection(sel_box, sel_col, scene)
        else:
            self._draw_multi_selection(sel_box, sel_col, scene, selection, sel_count, sel_names)
        self._draw_selection_status(sel_box)
        self._draw_advanced(sel_box, scene)

    @staticmethod
    def _draw_collection_selection(sel_box, sel_col, scene):
        coll_row = sel_box.row(align=True)
        coll_row.prop(scene, "cbb_collection_target", text="集合")
        coll_row.operator("cbb.use_selection_collection", text="", icon="FILE_REFRESH")
        target_coll = getattr(scene, "cbb_collection_target", None)
        try:
            selected_names = {obj.name for obj in (bpy.context.selected_objects or [])}
        except Exception:
            selected_names = set()
        if target_coll is not None:
            try:
                members = list(target_coll.objects)
            except Exception:
                members = []
            selected_in_coll = sum(1 for obj in members if obj.name in selected_names)
            sel_col.label(text="集合「%s」：%d 件（当前选中 %d 件）—— 保存整个集合"
                               % (target_coll.name, len(members), selected_in_coll), icon="OUTLINER_COLLECTION")
            # 成员列表：可折叠；展开后是 UIList（内容多时自带滚动条），高度用「高度（行）」滑杆调
            list_open = bool(getattr(scene, "cbb_show_collection_list", False))
            list_row = sel_box.row()
            list_row.prop(scene, "cbb_show_collection_list",
                          text="成员列表（%d）" % len(members), emboss=False,
                          icon="TRIA_DOWN" if list_open else "TRIA_RIGHT")
            if list_open:
                sel_box.prop(scene, "cbb_list_rows", text="高度（行）", slider=True)
                ctrl = sel_box.row(align=True)
                ctrl.operator("cbb.list_rows_dec", text="− 矮一点")
                ctrl.operator("cbb.list_rows_inc", text="+ 高一点")
                sel_box.template_list("CBB_UL_ObjectList", "cbb_collection",
                                      scene, "cbb_collection_items",
                                      scene, "cbb_collection_index",
                                      rows=int(getattr(scene, "cbb_list_rows", 8)), maxrows=30)
                if len(members) > LIST_UI_CAP:
                    sel_box.label(text="列表只显示前 %d 件（保存不受影响）" % LIST_UI_CAP, icon="INFO")
                if not members:
                    sel_box.label(text="集合是空的", icon="INFO")
            try:
                children = list(target_coll.children)
            except Exception:
                children = []
            if children:
                sel_box.label(text="子集合 %d 个：%s"
                                   % (len(children), "、".join(c.name for c in children[:4])), icon="OUTLINER_COLLECTION")
        else:
            sel_col.label(text="未选择集合：在上面的下拉里选一个", icon="INFO")
        send_row = sel_box.row()
        send_row.scale_y = 1.2
        send_row.enabled = target_coll is not None
        send_row.operator("cbb.send_collection_to_codex", text="保存集合给 Codex", icon="EXPORT")

    @staticmethod
    def _draw_multi_selection(sel_box, sel_col, scene, selection, sel_count, sel_names):
        if not sel_count:
            sel_col.label(text="未选中物体：在视口里选中后再保存", icon="INFO")
            send_row = sel_box.row()
            send_row.scale_y = 1.2
            send_row.enabled = False
            send_row.operator("cbb.send_selection_to_codex", text="保存选中给 Codex", icon="EXPORT")
            return
        try:
            sub_mode = str(getattr(bpy.context, "mode", "") or "")
        except Exception:
            sub_mode = ""
        if sub_mode and sub_mode != "OBJECT":
            try:
                sub_obj = getattr(bpy.context, "edit_object", None) or getattr(bpy.context, "active_object", None)
            except Exception:
                sub_obj = None
            if sub_obj is not None:
                sel_col.label(text="子元素：" + sub_mode_label(sub_mode) + " · " + sub_obj.name,
                              icon="EDITMODE_HLT")
        shown = "、".join(sel_names[:3])
        if sel_count > 3 or selection.get("truncated"):
            shown += "…"
        sel_col.label(text="已选 %d 件：%s" % (sel_count, shown), icon="OBJECT_DATA")
        if selection.get("active"):
            sel_col.label(text="活动对象：%s · 模式：%s"
                               % (selection.get("active"), selection.get("mode") or "?"))
        if sel_count > 200:
            sel_col.label(text="件数过多：切到「集合」模式整组保存更快", icon="INFO")
        try:
            selected_objs = list(bpy.context.selected_objects or [])
        except Exception:
            selected_objs = []
        list_open = bool(getattr(scene, "cbb_show_selection_list", False))
        list_row = sel_box.row()
        list_row.prop(scene, "cbb_show_selection_list",
                      text="对象 / 子元素列表（%d）" % len(selected_objs), emboss=False,
                      icon="TRIA_DOWN" if list_open else "TRIA_RIGHT")
        if list_open:
            sel_box.prop(scene, "cbb_list_rows", text="高度（行）", slider=True)
            ctrl = sel_box.row(align=True)
            ctrl.operator("cbb.list_rows_dec", text="− 矮一点")
            ctrl.operator("cbb.list_rows_inc", text="+ 高一点")
            sel_box.template_list("CBB_UL_ObjectList", "cbb_selection",
                                  scene, "cbb_selection_items",
                                  scene, "cbb_selection_index",
                                  rows=int(getattr(scene, "cbb_list_rows", 8)), maxrows=30)
            if len(selected_objs) > LIST_UI_CAP:
                sel_box.label(text="列表只显示前 %d 件（保存不受影响）" % LIST_UI_CAP, icon="INFO")
        send_row = sel_box.row()
        send_row.scale_y = 1.2
        send_row.enabled = True
        send_row.operator("cbb.send_selection_to_codex", text="保存选中给 Codex", icon="EXPORT")
        if 1 < sel_count <= 200:
            try:
                selected_now = list(bpy.context.selected_objects or [])
            except Exception:
                selected_now = []
            colls = selection_collection_summary(selected_now, cap=4)
            if colls:
                sel_col.label(text="选中涉及集合：" + "、".join(
                    "%s(%d)" % (c["name"], c["count"]) for c in colls), icon="OUTLINER_COLLECTION")

    @staticmethod
    def _draw_selection_status(sel_box):
        send_state = selection_commands._selection_send_state
        if send_state:
            if send_state.get("ok"):
                sel_box.label(text="最近保存：成功（seq %s）" % send_state.get("seq"), icon="CHECKMARK")
            else:
                sel_box.label(text="最近保存失败：" + str(send_state.get("error") or "unknown")[:120], icon="ERROR")

    @staticmethod
    def _draw_advanced(sel_box, scene):
        # 后端地址 / 覆盖项：折叠（排错时才展开）
        adv_open = bool(getattr(scene, "cbb_show_advanced", False))
        adv_row = sel_box.row()
        adv_row.prop(scene, "cbb_show_advanced", text="选区快照 / 高级", emboss=False,
                     icon="TRIA_DOWN" if adv_open else "TRIA_RIGHT")
        if adv_open:
            sel_box.label(text="选区快照保存在 Blender 配置目录", icon="INFO")

    @staticmethod
    def _draw_community(layout, context):
        # Community section
        layout.separator()
        community_box = layout.box()
        col = community_box.column(align=True)
        # Wrap by panel width so Blender doesn't elide the phrase mid-line.
        ui_scale = context.preferences.system.ui_scale
        region_width = context.region.width if context.region else 300
        chars = max(12, int((region_width - 30) / (7 * ui_scale)))
        for line in textwrap.wrap("Stay updated with the latest developments", chars):
            col.label(text=line)
        col.separator()
        row = col.row()
        row.scale_y = 1.3
        row.operator("wm.url_open", text="Join Discord", icon="URL").url = DISCORD_URL
