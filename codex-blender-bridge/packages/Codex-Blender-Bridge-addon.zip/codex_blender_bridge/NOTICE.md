Codex Blender Bridge adapts the Blender-side addon from
sixtysevenlf/dsh-blender-plugin v3.0.3 (addon v1.11), itself derived from
ahujasid/blender-mcp by Siddharth Ahuja (c) 2025, licensed MIT.
The source copyright header and author attribution are retained.
Original source: https://github.com/sixtysevenlf/dsh-blender-plugin
Changes: independent package name/UI identity, port 9878, local selection
inbox, and token-authenticated local command transport.

The bundled runtime/py source is from dsh-blender-plugin v3.0.3
under BSD-3-Clause; its repository license is included in the full package.
The bundled backend/lib/runtime JavaScript is compiled from that same source
with a local-token transport adaptation; its BSD-3-Clause license is included.
