""" assets subpackage for the Codex Blender Bridge add-on. """
