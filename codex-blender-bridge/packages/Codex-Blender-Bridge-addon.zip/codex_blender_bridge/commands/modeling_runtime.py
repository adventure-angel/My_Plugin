"""Expose the bundled DSH modeling runtime to the local Codex bridge.

The upstream Python modules run inside Blender and register their public
operations on a persistent kernel. Loading is lazy so optional dependencies
in one domain do not prevent the base bridge from starting.
"""

import importlib.util
import json
import sys
from pathlib import Path


_RUNTIME = Path(__file__).resolve().parents[1] / "runtime"
_MANIFEST = _RUNTIME / "py" / "modules.json"
_BOOTSTRAP = _RUNTIME / "py" / "core" / "offline_bootstrap.py"
_BOOT = None
_APIS = {}
_INFRA = {"kit", "worker", "offline_bootstrap", "render_guard", "imgtools", "open3d_check"}
_ALIASES = {"runner": "loop", "planner": "plan", "presets": "preset",
            "pipeline": "pipe", "mesh_fix": "fix", "shapegen": "shape",
            "faceeval": "face", "printcheck": "print", "uv_tools": "uv"}


def _modules():
    return json.loads(_MANIFEST.read_text(encoding="utf-8"))["modules"]


def _boot():
    global _BOOT
    if _BOOT is None:
        spec = importlib.util.spec_from_file_location("cbb_modeling_bootstrap", _BOOTSTRAP)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _BOOT = module
    return _BOOT


def _api(module):
    if module in _APIS:
        return _APIS[module]
    modules = _modules()
    if module not in modules:
        raise ValueError("Unknown modeling module: %s" % module)
    # The upstream implementation imports runtime.py.* as a top-level package.
    addon_dir = str(_RUNTIME.parent)
    if addon_dir not in sys.path:
        sys.path.insert(0, addon_dir)
    ns = _boot().boot([module], runtime_dir=str(_RUNTIME))
    api_name = _ALIASES.get(module, module)
    api = getattr(ns["K"], "dsh_%s_api" % api_name, None)
    if api is None:
        raise ValueError("%s is an infrastructure module without a public operation API" % module)
    _APIS[module] = api
    return api


class ModelingRuntimeCommands:
    def modeling_modules(self):
        """List every bundled upstream modeling module without loading it."""
        modules = _modules()
        return {"source": "dsh-blender-plugin v3.0.3",
                "public_modules": {k: v for k, v in modules.items() if k not in _INFRA},
                "infrastructure_modules": sorted(_INFRA)}

    def modeling_catalog(self, module):
        """List operations registered by one module."""
        api = _api(module)
        return {"module": module, "version": api.get("version"),
                "operations": sorted(k for k, v in api.items() if callable(v) and k != "dispatch")}

    def modeling_op(self, module, op, args=None):
        """Run one upstream modeling operation through its own dispatcher."""
        if not op or not isinstance(op, str):
            raise ValueError("op must be a non-empty string")
        if args is None:
            args = {}
        if not isinstance(args, dict):
            raise ValueError("args must be a JSON object")
        api = _api(module)
        result = api["dispatch"](op, json.dumps(args, ensure_ascii=False))
        if isinstance(result, str):
            try:
                return json.loads(result)
            except json.JSONDecodeError:
                return {"text": result}
        return result
